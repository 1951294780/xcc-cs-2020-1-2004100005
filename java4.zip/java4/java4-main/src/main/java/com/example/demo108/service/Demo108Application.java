package com.example.demo108;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo108Application {

    public static void main(String[] args) {
        SpringApplication.run(Demo108Application.class, args);
    }

}
